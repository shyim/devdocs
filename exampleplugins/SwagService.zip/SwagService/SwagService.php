<?php

namespace SwagService;

use Shopware\Components\Plugin;

class SwagService extends Plugin
{

}
