
Ext.define('Shopware.apps.SwagProductListingExtension.view.detail.Attribute', {
    extend: 'Shopware.model.Container',
//    padding: 20,

    configure: function() {
        return {
            fieldAlias: 'attribute'
        }
    }
});