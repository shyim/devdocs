<?php

namespace SwagSloganOfTheDay;

use Shopware\Components\Plugin;

class SwagSloganOfTheDay extends Plugin
{

}
