<?php

namespace SwagSearchBundle;

use Shopware\Components\Plugin;

class SwagSearchBundle extends Plugin
{

}
