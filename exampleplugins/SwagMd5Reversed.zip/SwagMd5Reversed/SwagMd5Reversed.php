<?php

namespace SwagMd5Reversed;

use Shopware\Components\Plugin;

class SwagMd5Reversed extends Plugin
{

}