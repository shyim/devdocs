<?php

namespace SwagEvents;

use Shopware\Components\Plugin;

class SwagEvents extends Plugin
{
    
}