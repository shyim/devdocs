<?php

namespace SwagCustomProductBoxLayout;

use Shopware\Components\Plugin;
use Symfony\Component\DependencyInjection\ContainerBuilder;

/**
 * Shopware-Plugin SwagCustomProductBoxLayout.
 */
class SwagCustomProductBoxLayout extends Plugin
{

}
