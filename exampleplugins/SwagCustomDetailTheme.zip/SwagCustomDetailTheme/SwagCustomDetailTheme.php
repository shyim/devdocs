<?php

namespace SwagCustomDetailTheme;

use Shopware\Components\Plugin;

class SwagCustomDetailTheme extends Plugin
{

}
